import pypownet.agent
import pypownet.environment
from sklearn.neural_network import MLPClassifier
import pickle
import numpy as np

class Submission(pypownet.agent.Agent):
    """
    An agent which load the parameters of a multi-layer perceptron previously trained, 
    in order to predict the action to take given an observations.
    The MLP predict the id of the action, which is train transformed into a numpy array, and then into an Action object.
    """

    def __init__(self, environment):
        super().__init__(environment)
        
        filename_clf = 'program/parameters_MLP.sav' # example_submission/parameters_MLP.sav
        filename_U = 'program/tableauU.npy' # 'example_submission/tableauU.npy'
        self.clf = pickle.load(open(filename_clf, 'rb'))
        self.U = np.load(filename_U)
        
        self.nb_labels = self.U.shape[0]

    def act(self, observation):
        # Sanity check: an observation is a structured object defined in the environment file.
        assert isinstance(observation, pypownet.environment.Observation)
        action_space = self.environment.action_space

        
        x = observation.as_array()
        action_id = self.clf.predict(np.array([x]))[0]
        action_arr = self.U[action_id]
        action = action_space.array_to_action(action_arr)
        

        return action

        # No learning (i.e. self.feed_reward does pass)


